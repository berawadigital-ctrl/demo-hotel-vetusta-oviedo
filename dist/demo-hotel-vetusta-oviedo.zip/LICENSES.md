# Licencias de los activos

| Activo | Origen | Autor | Licencia |
|---|---|---|---|
| img/hero.webp (+ hero-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `skyline`, semilla 9101) | Berawa Solutions | Propia (generada por script) |
| img/intro.webp (+ intro-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `columns`, semilla 9102) | Berawa Solutions | Propia (generada por script) |
| img/r1.webp (+ r1-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `arches`, semilla 9111) | Berawa Solutions | Propia (generada por script) |
| img/r2.webp (+ r2-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `hills`, semilla 9112) | Berawa Solutions | Propia (generada por script) |
| img/r3.webp (+ r3-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `columns`, semilla 9113) | Berawa Solutions | Propia (generada por script) |
| img/r4.webp (+ r4-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `waves`, semilla 9114) | Berawa Solutions | Propia (generada por script) |
| img/g1.webp (+ g1-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `skyline`, semilla 9121) | Berawa Solutions | Propia (generada por script) |
| img/g2.webp (+ g2-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `hills`, semilla 9122) | Berawa Solutions | Propia (generada por script) |
| img/g3.webp (+ g3-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `arches`, semilla 9123) | Berawa Solutions | Propia (generada por script) |
| img/g4.webp (+ g4-m.webp) | Ilustración generada por código (`berawa/build/make_art.py`, tipo `waves`, semilla 9124) | Berawa Solutions | Propia (generada por script) |
| fonts/cormorant.woff2 | https://github.com/CatharsisFonts/Cormorant | Christian Thalmann (Catharsis Fonts) | SIL OFL 1.1 |

Ninguna imagen es una foto ni muestra el establecimiento: son ilustraciones propias y se rotulan «Imagen ilustrativa». Detalle por fichero (hash, parámetros de generación) en `berawa/asset_manifest.json` y `berawa/evidence/assets/`.

Los textos proceden de la web pública del negocio (hotelvetusta.com, leída el 30/10/2026; ver `berawa/sources.json`); no se han copiado sus fotos, logotipos, vídeos ni testimonios.
